"""
This module is primarily a copy of the code at https://introcs.cs.princeton.edu/python/code/ written by 
Robert Sedgewick, Kevin Wayne, and Robert Dondero
"""